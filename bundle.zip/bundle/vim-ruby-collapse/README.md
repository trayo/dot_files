# Vim Ruby Collapse

Use pathogen and install it with:
```
cd ~/.vim/bundle
git clone https://github.com/trayo/vim-ruby-collapse.git
```

