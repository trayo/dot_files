package mypackage

import "testing"

func TestNumbers(*testing.T) {
    // assertions
}
