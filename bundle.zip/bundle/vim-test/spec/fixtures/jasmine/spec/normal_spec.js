describe('Addition', function() {
  it('adds two numbers', function() {
    expect(1 + 1).toEqual(true);
  });
});
