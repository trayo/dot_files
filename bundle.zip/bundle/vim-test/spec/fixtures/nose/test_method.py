def test_numbers():
    assert 1 == 1
