class TestNumbers:
    def test_numbers(self):
        assert 1 == 1
