defmodule NumbersTest do
  use ExUnit.Case

  test "numbers" do
    assert 1 == 1
  end
end
