describe('Math', function() {
  describe('Addition', function() {
    it('adds two numbers', function() {
      // assertions
    });
  });
});
