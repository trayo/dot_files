describe('Addition', function() {
  it('adds two numbers', function() {
    assertEqual(1 + 1 == 2)
  });
});
