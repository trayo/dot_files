RSpec.describe "Addition" do
  it "adds to numbers" do
    expect(1 + 1).to eq 2
  end
end
