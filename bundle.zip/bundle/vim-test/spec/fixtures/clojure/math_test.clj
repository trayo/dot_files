(ns math-test)

(deftest a-test
  (testing "Test 1"
    (is (= 1 1))))

(deftest another-test
  (testing "Test 2"
    (is (= 1 1))))
